export const educationData = [
  {
    degree: "Bachelor of Science in Computer Science",
    institution: "State University",
    year: "2018 - 2022"
  },
  {
    degree: "DevOps Engineering Bootcamp",
    institution: "Tech Academy",
    year: "2022"
  }
];